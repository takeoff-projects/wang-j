package cf
import (
    "fmt"
    "time"
    "context"
    "google.golang.org/api/pubsub/v1"
    "cloud.google.com/go/datastore"
)

type ImportMessage struct {
	timestamp string
    message string
}

func ProcessOsrImport(ctx context.Context, body pubsub.PubsubMessage) error {
    fmt.Println("hello world")
    fmt.Println(string(body.Data))
    // TODO: Take project out of environment
    client, clientErr := datastore.NewClient(ctx, "roi-takeoff-user44")
    if clientErr != nil {
		fmt.Println("I Should put some error here -- Client Creation: " + clientErr.Error())
        return nil
	}
    message := new(ImportMessage)
	message.timestamp = time.Now().Format(time.RFC822Z)
    message.message = body.Data

    k := datastore.NameKey("import_message", "stringID", nil)

	_, dbErr := client.Put(ctx, k, message)
    if dbErr != nil {
		fmt.Println("I Should put some error here -- DB PUT: " + dbErr.Error())
        return nil
	}
    return nil
}
