package cf
import (
    "fmt"
    "time"
    "context"
    "google.golang.org/api/pubsub/v1"

    firebase "firebase.google.com/go"
    "google.golang.org/api/option"
  )

type ImportMessage struct {
	timestamp string
    message string
}

func ProcessOsrImport(ctx context.Context, body pubsub.PubsubMessage) error {
    fmt.Println("hello world")
    message := new(ImportMessage)
	message.timestamp = time.Now().Format(time.RFC822Z)
    message.message = body.Data

    newCtx := context.Background()
    conf := &firebase.Config{ProjectID: "roi-takeoff-user44"}
    app, appErr := firebase.NewApp(newCtx, conf)
    if appErr != nil {
        fmt.Println("1")
        fmt.Print(appErr)
    }

    client, firestoreErr := app.Firestore(newCtx)
    if firestoreErr != nil {
        fmt.Println("2")
        fmt.Print(firestoreErr)
    }
    defer client.Close()

    _, _, collectionErr := client.Collection("import_messages").Add(newCtx, message)
    if collectionErr != nil {
        fmt.Println("3")
        fmt.Print(collectionErr)
    }

    return nil
}
