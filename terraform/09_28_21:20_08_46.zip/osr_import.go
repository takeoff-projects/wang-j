package cf
import (
    "fmt"
    "time"
    "context"
    "google.golang.org/api/pubsub/v1"

    firebase "firebase.google.com/go"
  )

type ImportMessage struct {
	timestamp string `firestore:"timestamp,omitempty"`
    message   string `firestore:"message,omitempty"`
}

func ProcessOsrImport(ctx context.Context, body pubsub.PubsubMessage) error {
    message := new(ImportMessage)
	message.timestamp = time.Now().Format(time.RFC822Z)
    message.message = body.Data
    fmt.Println(message)

    conf := &firebase.Config{ProjectID: "roi-takeoff-user44"}
    app, appErr := firebase.NewApp(ctx, conf)
    if appErr != nil {
        fmt.Println("1")
        fmt.Print(appErr)
    }

    client, firestoreErr := app.Firestore(ctx)
    if firestoreErr != nil {
        fmt.Println("2")
        fmt.Print(firestoreErr)
    }

    _, _, collectionErr := client.Collection("import_messages").Add(ctx, message)
    if collectionErr != nil {
        fmt.Println("3")
        fmt.Print(collectionErr)
    }
    defer client.Close()

    return nil
}
